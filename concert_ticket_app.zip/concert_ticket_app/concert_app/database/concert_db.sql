CREATE DATABASE IF NOT EXISTS concert_db;
USE concert_db;

--  TABEL 1: concerts
--  Menyimpan data konser

CREATE TABLE concerts (
    id          INT AUTO_INCREMENT PRIMARY KEY,  -- nomor urut, otomatis bertambah
    title       VARCHAR(100) NOT NULL,           -- judul konser
    artist      VARCHAR(100) NOT NULL,           -- nama artis
    venue       VARCHAR(150) NOT NULL,           -- tempat konser
    event_date  DATE         NOT NULL,           -- tanggal konser
    price       INT          NOT NULL,           -- harga tiket (Rupiah)
    quota       INT          NOT NULL,           -- total tiket tersedia
    created_at  DATETIME     DEFAULT CURRENT_TIMESTAMP  -- waktu data dibuat (otomatis)
);

--  TABEL 2: customers
--  Menyimpan data pembeli tiket

CREATE TABLE customers (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    name        VARCHAR(100) NOT NULL,           -- nama lengkap pembeli
    email       VARCHAR(100) NOT NULL UNIQUE,    -- email (tidak boleh sama/duplikat)
    phone       VARCHAR(20)  NOT NULL,           -- nomor HP
    created_at  DATETIME     DEFAULT CURRENT_TIMESTAMP
);

--  TABEL 3: tickets
--  Menyimpan data pembelian tiket
--  Tabel ini menghubungkan concerts dan customers

CREATE TABLE tickets (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    concert_id  INT NOT NULL,                   -- merujuk ke tabel concerts
    customer_id INT NOT NULL,                   -- merujuk ke tabel customers
    quantity    INT NOT NULL DEFAULT 1,         -- jumlah tiket yang dibeli
    total_price INT NOT NULL,                   -- total harga = quantity x price
    status      VARCHAR(20) DEFAULT 'paid',     -- status: paid / cancelled
    created_at  DATETIME DEFAULT CURRENT_TIMESTAMP,

    -- Hubungkan ke tabel concerts
    -- ON DELETE CASCADE = kalau konser dihapus, tiketnya ikut terhapus
    FOREIGN KEY (concert_id)  REFERENCES concerts  (id) ON DELETE CASCADE,

    -- Hubungkan ke tabel customers
    FOREIGN KEY (customer_id) REFERENCES customers (id) ON DELETE CASCADE
);


-- ================================================================
--  DATA CONTOH
--  Supaya aplikasi tidak kosong saat pertama kali dibuka
-- ================================================================

INSERT INTO concerts (title, artist, venue, event_date, price, quota) VALUES
('Konser Akhir Tahun',    'Raisa',     'GBK Jakarta',       '2025-12-31', 500000, 1000),
('Summer Vibes Festival', 'Pamungkas', 'Sentul, Bogor',     '2025-08-10', 350000, 2000),
('Nostalgia 90an',        'Dewa 19',   'JIExpo Kemayoran',  '2025-09-15', 300000, 5000);

INSERT INTO customers (name, email, phone) VALUES
('Budi Santoso', 'budi@email.com', '081234567890'),
('Sari Dewi',    'sari@email.com', '082345678901');

INSERT INTO tickets (concert_id, customer_id, quantity, total_price, status) VALUES
(1, 1, 2, 1000000, 'paid'),
(2, 2, 1,  350000, 'paid');
