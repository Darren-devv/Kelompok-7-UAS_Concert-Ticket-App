USE concert_db;
ALTER TABLE customers ADD COLUMN IF NOT EXISTS password VARCHAR(255) NOT NULL DEFAULT '';
CREATE TABLE IF NOT EXISTS admins (
    id         INT AUTO_INCREMENT PRIMARY KEY,
    username   VARCHAR(100) NOT NULL UNIQUE,
    password   VARCHAR(255) NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);
-- Insert akun admin (PW di hash)
-- username: admin | password: admin123
INSERT IGNORE INTO admins (username, password)
VALUES ('admin', 'pbkdf2:sha256:600000$salt$hashed');


