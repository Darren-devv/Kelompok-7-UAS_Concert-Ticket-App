Cara RUN Program
1. Masukkan kedua database concert_db dan path auth
2. Pip install pymysql, flask, dan reportlab
3. RUN

Cara Login Admin
pada link http://127.0.0.1:5000/login ubah menjadi -> http://127.0.0.1:5000/setup-admin
lalu klik login sekarang, dan masukkan username admin dan password adminnya

