Cara RUN
- Buat venv yang baru. Karena folder venv tidak kami sertakan dalam source code ini akibat ukurannya yang besar apabila menyertakan venv
- Install library yang ada di requirements.txt
- Import kedua database yaitu concert_db an patch_auth

Cara Login sebagai Admin
- Pada saat run di http://127.0.0.1:5000 tambahkan dibelakangnya /setup-admin menjadi http://127.0.0.1:5000/setup-admin
- Klik "Login Sekarang"
- Masukkan Username dan Password
  Username : admin
  Password : admin123


