from flask import Flask, render_template, request, redirect, url_for, flash, session, send_file
from werkzeug.security import generate_password_hash, check_password_hash
import pymysql
from functools import wraps
import io
from datetime import datetime
from reportlab.lib.pagesizes import A4, landscape
from reportlab.lib import colors
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer

app = Flask(__name__)
app.secret_key = 'concert123'


#  OOP - Class Database (Encapsulation)
class Database:
    def __init__(self, host, user, password, database):
        self.host = host
        self.user = user
        self.password = password
        self.database = database

    def get_connection(self):
        connection = pymysql.connect(
            host=self.host,
            user=self.user,
            password=self.password,
            database=self.database,
            cursorclass=pymysql.cursors.DictCursor
        )
        return connection



#  OOP - Class dasar (Base Class) untuk semua model data

class Model:
    def __init__(self, db_connection):
        self.db = db_connection
        self.cursor = db_connection.cursor()

    def close(self):
        self.db.close()



#  OOP - Class Concert, mewarisi class Model
class Concert(Model):
    def __init__(self, db_connection):
        super().__init__(db_connection)

    def get_all(self):
        """
        Ambil semua konser, lengkap dengan sisa_kuota dan status (sold out / available).
        Kursi terjual dihitung dari tiket yang sudah 'paid' ATAU 'pending'
        (supaya kuota tidak dijual berlebih saat ada pesanan yang masih menunggu bayar).
        """
        self.cursor.execute("""
            SELECT c.*,
                   COALESCE(SUM(CASE WHEN t.status IN ('paid', 'pending') THEN t.quantity ELSE 0 END), 0) AS kursi_terpakai
            FROM concerts c
            LEFT JOIN tickets t ON t.concert_id = c.id
            GROUP BY c.id
            ORDER BY c.event_date ASC
        """)
        rows = self.cursor.fetchall()
        for r in rows:
            sisa = r['quota'] - r['kursi_terpakai']
            r['sisa_kuota'] = sisa if sisa > 0 else 0
            r['is_sold_out'] = r['sisa_kuota'] <= 0
            r['status_tiket'] = 'Sold Out' if r['is_sold_out'] else 'Tersedia'
        return rows

    def get_by_id(self, id):
        """
        Ambil satu konser by id, lengkap dengan sisa_kuota dan status sold out.
        """
        self.cursor.execute("""
            SELECT c.*,
                   COALESCE(SUM(CASE WHEN t.status IN ('paid', 'pending') THEN t.quantity ELSE 0 END), 0) AS kursi_terpakai
            FROM concerts c
            LEFT JOIN tickets t ON t.concert_id = c.id
            WHERE c.id = %s
            GROUP BY c.id
        """, (id,))
        row = self.cursor.fetchone()
        if row:
            sisa = row['quota'] - row['kursi_terpakai']
            row['sisa_kuota'] = sisa if sisa > 0 else 0
            row['is_sold_out'] = row['sisa_kuota'] <= 0
            row['status_tiket'] = 'Sold Out' if row['is_sold_out'] else 'Tersedia'
        return row

    def tambah(self, title, artist, venue, event_date, price, quota):
        self.cursor.execute(
            "INSERT INTO concerts (title, artist, venue, event_date, price, quota) VALUES (%s, %s, %s, %s, %s, %s)",
            (title, artist, venue, event_date, price, quota)
        )
        self.db.commit()

    def update(self, id, title, artist, venue, event_date, price, quota):
        self.cursor.execute(
            "UPDATE concerts SET title=%s, artist=%s, venue=%s, event_date=%s, price=%s, quota=%s WHERE id=%s",
            (title, artist, venue, event_date, price, quota, id)
        )
        self.db.commit()

    def hapus(self, id):
        self.cursor.execute("DELETE FROM concerts WHERE id = %s", (id,))
        self.db.commit()

    def hitung_total(self):
        self.cursor.execute("SELECT COUNT(*) AS total FROM concerts")
        return self.cursor.fetchone()['total']



#  OOP - Class Customer, mewarisi class Model (Inheritance)
#  Polymorphism: method tambah() punya perilaku berbeda
class Customer(Model):
    def __init__(self, db_connection):
        super().__init__(db_connection)

    def get_all(self):
        self.cursor.execute("SELECT * FROM customers ORDER BY name ASC")
        return self.cursor.fetchall()

    def get_by_id(self, id):
        self.cursor.execute("SELECT * FROM customers WHERE id = %s", (id,))
        return self.cursor.fetchone()

    def get_by_email(self, email):
        self.cursor.execute("SELECT * FROM customers WHERE email = %s", (email,))
        return self.cursor.fetchone()

    def tambah(self, name, email, phone, password):
        hashed = generate_password_hash(password)
        self.cursor.execute(
            "INSERT INTO customers (name, email, phone, password) VALUES (%s, %s, %s, %s)",
            (name, email, phone, hashed)
        )
        self.db.commit()

    def update(self, id, name, email, phone):
        self.cursor.execute(
            "UPDATE customers SET name=%s, email=%s, phone=%s WHERE id=%s",
            (name, email, phone, id)
        )
        self.db.commit()

    def hapus(self, id):
        self.cursor.execute("DELETE FROM customers WHERE id = %s", (id,))
        self.db.commit()

    def hitung_total(self):
        self.cursor.execute("SELECT COUNT(*) AS total FROM customers")
        return self.cursor.fetchone()['total']


#  OOP - Class Ticket, mewarisi class Model (Inheritance)
class Ticket(Model):
    def __init__(self, db_connection):
        super().__init__(db_connection)

    def get_all(self):
        self.cursor.execute("""
            SELECT t.id, c.title AS concert_title, cu.name AS customer_name,
                   t.quantity, t.total_price, t.status, t.created_at
            FROM tickets t
            JOIN concerts c   ON t.concert_id  = c.id
            JOIN customers cu ON t.customer_id = cu.id
            ORDER BY t.created_at DESC
        """)
        return self.cursor.fetchall()

    def get_by_customer(self, customer_id):
        self.cursor.execute("""
            SELECT t.id, c.title AS concert_title, c.artist, c.venue,
                   c.event_date, t.quantity, t.total_price, t.status, t.created_at
            FROM tickets t
            JOIN concerts c ON t.concert_id = c.id
            WHERE t.customer_id = %s
            ORDER BY t.created_at DESC
        """, (customer_id,))
        return self.cursor.fetchall()

    def get_by_id(self, id):
        self.cursor.execute("SELECT * FROM tickets WHERE id = %s", (id,))
        return self.cursor.fetchone()

    def tambah(self, concert_id, customer_id, quantity, total_price, status='pending'):
        self.cursor.execute(
            "INSERT INTO tickets (concert_id, customer_id, quantity, total_price, status) VALUES (%s, %s, %s, %s, %s)",
            (concert_id, customer_id, quantity, total_price, status)
        )
        self.db.commit()
        return self.cursor.lastrowid

    def update(self, id, concert_id, customer_id, quantity, total_price, status):
        self.cursor.execute(
            "UPDATE tickets SET concert_id=%s, customer_id=%s, quantity=%s, total_price=%s, status=%s WHERE id=%s",
            (concert_id, customer_id, quantity, total_price, status, id)
        )
        self.db.commit()

    def hapus(self, id):
        self.cursor.execute("DELETE FROM tickets WHERE id = %s", (id,))
        self.db.commit()

    def konfirmasi_bayar(self, id):
        self.cursor.execute("UPDATE tickets SET status = 'paid' WHERE id = %s", (id,))
        self.db.commit()

    def hitung_total_paid(self):
        self.cursor.execute("SELECT COUNT(*) AS total FROM tickets WHERE status = 'paid'")
        return self.cursor.fetchone()['total']

    def hitung_total_revenue(self):
        self.cursor.execute("SELECT SUM(total_price) AS total FROM tickets WHERE status = 'paid'")
        result = self.cursor.fetchone()
        return result['total'] if result['total'] else 0

    def get_laporan(self, status_filter=None):
        if status_filter and status_filter != 'semua':
            self.cursor.execute("""
                SELECT t.id, c.title AS concert_title, c.artist, c.venue,
                       cu.name AS customer_name, t.quantity, t.total_price,
                       t.status, t.created_at
                FROM tickets t
                JOIN concerts c   ON t.concert_id  = c.id
                JOIN customers cu ON t.customer_id = cu.id
                WHERE t.status = %s
                ORDER BY t.created_at DESC
            """, (status_filter,))
        else:
            self.cursor.execute("""
                SELECT t.id, c.title AS concert_title, c.artist, c.venue,
                       cu.name AS customer_name, t.quantity, t.total_price,
                       t.status, t.created_at
                FROM tickets t
                JOIN concerts c   ON t.concert_id  = c.id
                JOIN customers cu ON t.customer_id = cu.id
                ORDER BY t.created_at DESC
            """)
        return self.cursor.fetchall()

    def get_rekap_per_konser(self):
        self.cursor.execute("""
            SELECT c.title, c.artist,
                   COUNT(t.id) AS jumlah_tiket,
                   SUM(t.quantity) AS total_kursi,
                   SUM(t.total_price) AS total_pendapatan
            FROM tickets t
            JOIN concerts c ON t.concert_id = c.id
            GROUP BY c.id, c.title, c.artist
            ORDER BY total_pendapatan DESC
        """)
        return self.cursor.fetchall()

    def get_live_data_per_konser(self):
        # LEFT JOIN supaya konser yang belum ada penjualan tetap tampil (live view dashboard)
        self.cursor.execute("""
            SELECT c.id, c.title, c.artist, c.venue, c.event_date,
                   c.price, c.quota,
                   COALESCE(SUM(CASE WHEN t.status = 'paid' THEN t.quantity ELSE 0 END), 0) AS kursi_terjual,
                   COALESCE(COUNT(CASE WHEN t.status = 'paid' THEN t.id END), 0) AS jumlah_transaksi,
                   COALESCE(SUM(CASE WHEN t.status = 'paid' THEN t.total_price ELSE 0 END), 0) AS total_pendapatan
            FROM concerts c
            LEFT JOIN tickets t ON t.concert_id = c.id
            GROUP BY c.id, c.title, c.artist
            ORDER BY c.event_date ASC
        """)
        rows = self.cursor.fetchall()

        for r in rows:
            r['sisa_kuota'] = r['quota'] - r['kursi_terjual']
            r['persen_terjual'] = round((r['kursi_terjual'] / r['quota']) * 100, 1) if r['quota'] else 0

        return rows



#  Helper: buat koneksi database (pakai class Database)
db_config = Database(
    host='localhost',
    user='root',
    password='',
    database='concert_db'
)

def get_db():
    return db_config.get_connection()


def login_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        if 'customer_id' not in session:
            flash('Silakan login terlebih dahulu.', 'warning')
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated

def admin_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        if session.get('role') != 'admin':
            flash('Akses ditolak. Halaman khusus admin.', 'danger')
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated


# Auth

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        name     = request.form['name']
        email    = request.form['email']
        phone    = request.form['phone']
        password = request.form['password']
        confirm  = request.form['confirm']

        if password != confirm:
            flash('Password dan konfirmasi tidak cocok!', 'danger')
            return redirect(url_for('register'))

        db = get_db()
        customer = Customer(db)
        existing = customer.get_by_email(email)
        if existing:
            customer.close()
            flash('Email sudah terdaftar. Silakan login.', 'warning')
            return redirect(url_for('login'))

        customer.tambah(name, email, phone, password)
        customer.close()
        flash('Registrasi berhasil! Silakan login.', 'success')
        return redirect(url_for('login'))

    return render_template('register.html')


@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        login_input = request.form['email'].strip()
        password    = request.form['password']

        db = get_db()
        cursor = db.cursor()

        cursor.execute("SELECT * FROM admins WHERE username = %s", (login_input,))
        admin = cursor.fetchone()
        if admin:
            stored = admin['password'] or ''
            if stored and check_password_hash(stored, password):
                session['role']     = 'admin'
                session['username'] = admin['username']
                db.close()
                flash(f"Selamat datang, {admin['username']}!", 'success')
                return redirect(url_for('index'))

        customer_obj = Customer(db)
        customer = customer_obj.get_by_email(login_input)
        customer_obj.close()

        if customer:
            stored = customer['password'] or ''
            if stored and check_password_hash(stored, password):
                session['role']        = 'customer'
                session['customer_id'] = customer['id']
                session['name']        = customer['name']
                flash(f"Selamat datang, {customer['name']}!", 'success')
                return redirect(url_for('portal'))
            elif not stored:
                flash('Akun ini belum punya password. Silakan daftar ulang.', 'warning')
                return redirect(url_for('login'))

        flash('Email/username atau password salah.', 'danger')
        return redirect(url_for('login'))

    return render_template('login.html')


@app.route('/logout')
def logout():
    session.clear()
    flash('Kamu sudah logout.', 'info')
    return redirect(url_for('login'))


@app.route('/setup-admin')
def setup_admin():
    db = get_db()
    cursor = db.cursor()
    hashed = generate_password_hash('admin123')
    cursor.execute(
        "INSERT INTO admins (username, password) VALUES (%s, %s) ON DUPLICATE KEY UPDATE password = VALUES(password)",
        ('admin', hashed)
    )
    db.commit()
    db.close()
    return '<p>Admin siap! Username: <b>admin</b> | Password: <b>admin123</b>. <a href="/login">Login sekarang</a></p>'



#  Portal Customer

@app.route('/portal')
@login_required
def portal():
    db = get_db()
    concert = Concert(db)
    concerts = concert.get_all()
    concert.close()
    return render_template('portal/home.html', concerts=concerts)


@app.route('/portal/book/<int:concert_id>', methods=['GET', 'POST'])
@login_required
def portal_book(concert_id):
    db = get_db()
    concert_obj = Concert(db)
    concert = concert_obj.get_by_id(concert_id)

    if not concert:
        flash('Konser tidak ditemukan.', 'danger')
        concert_obj.close()
        return redirect(url_for('portal'))

    if concert['is_sold_out']:
        flash('Maaf, tiket konser ini sudah Sold Out.', 'danger')
        concert_obj.close()
        return redirect(url_for('portal'))

    if request.method == 'POST':
        quantity = int(request.form['quantity'])

        if quantity < 1:
            flash('Jumlah tiket tidak valid.', 'danger')
            concert_obj.close()
            return redirect(url_for('portal_book', concert_id=concert_id))

        if quantity > concert['sisa_kuota']:
            flash(f"Maaf, sisa kuota tiket hanya {concert['sisa_kuota']}. Tiket sudah hampir/sudah Sold Out.", 'danger')
            concert_obj.close()
            return redirect(url_for('portal_book', concert_id=concert_id))

        customer_id = session['customer_id']
        total_price = concert['price'] * quantity

        ticket = Ticket(db)
        # Tiket dibuat dengan status 'pending', menunggu pembayaran
        ticket_id = ticket.tambah(concert_id, customer_id, quantity, total_price, status='pending')
        concert_obj.close()

        flash('Pesanan berhasil dibuat! Selesaikan pembayaran untuk mengonfirmasi tiket.', 'info')
        return redirect(url_for('portal_payment', ticket_id=ticket_id))

    concert_obj.close()
    return render_template('portal/book.html', concert=concert)


@app.route('/portal/payment/<int:ticket_id>')
@login_required
def portal_payment(ticket_id):
    db = get_db()
    ticket_obj = Ticket(db)
    ticket = ticket_obj.get_by_id(ticket_id)

    if not ticket or ticket['customer_id'] != session['customer_id']:
        flash('Tiket tidak ditemukan.', 'danger')
        ticket_obj.close()
        return redirect(url_for('portal_my_tickets'))

    # Ambil nama konser
    cursor = db.cursor()
    cursor.execute("SELECT title FROM concerts WHERE id = %s", (ticket['concert_id'],))
    concert = cursor.fetchone()
    concert_title = concert['title'] if concert else 'Konser'

    ticket_obj.close()
    return render_template('portal/payment.html',
        ticket_id=ticket_id,
        concert_title=concert_title,
        total_price=ticket['total_price']
    )


@app.route('/portal/confirm-payment/<int:ticket_id>')
@login_required
def portal_confirm_payment(ticket_id):
    db = get_db()
    ticket_obj = Ticket(db)
    ticket = ticket_obj.get_by_id(ticket_id)

    if ticket and ticket['customer_id'] == session['customer_id']:
        ticket_obj.konfirmasi_bayar(ticket_id)
        flash('Pembayaran berhasil! Tiket kamu sudah aktif.', 'success')
    else:
        flash('Tiket tidak ditemukan.', 'danger')

    ticket_obj.close()
    return redirect(url_for('portal_my_tickets'))


@app.route('/portal/my-tickets')
@login_required
def portal_my_tickets():
    db = get_db()
    ticket = Ticket(db)
    tickets = ticket.get_by_customer(session['customer_id'])
    ticket.close()
    return render_template('portal/my_tickets.html', tickets=tickets)


@app.route('/portal/cancel/<int:ticket_id>')
@login_required
def portal_cancel(ticket_id):
    db = get_db()
    ticket_obj = Ticket(db)
    ticket = ticket_obj.get_by_id(ticket_id)
    if ticket and ticket['customer_id'] == session['customer_id']:
        # Hapus tiket dari database (bukan hanya update status)
        ticket_obj.hapus(ticket_id)
        flash('Tiket berhasil dibatalkan dan dihapus.', 'warning')
    else:
        flash('Tiket tidak ditemukan.', 'danger')
    ticket_obj.close()
    return redirect(url_for('portal_my_tickets'))


@app.route('/portal/profile', methods=['GET', 'POST'])
@login_required
def portal_profile():
    db = get_db()
    customer_obj = Customer(db)

    if request.method == 'POST':
        name  = request.form['name']
        phone = request.form['phone']
        existing = customer_obj.get_by_id(session['customer_id'])
        customer_obj.update(session['customer_id'], name, existing['email'], phone)
        session['name'] = name
        flash('Profil berhasil diupdate!', 'success')
        customer_obj.close()
        return redirect(url_for('portal_profile'))

    customer = customer_obj.get_by_id(session['customer_id'])
    customer_obj.close()
    return render_template('portal/profile.html', customer=customer)


# Admin Dashboard
@app.route('/')
@admin_required
def index():
    db = get_db()
    concert_obj  = Concert(db)
    customer_obj = Customer(db)
    ticket_obj   = Ticket(db)

    total_concerts  = concert_obj.hitung_total()
    total_customers = customer_obj.hitung_total()
    total_tickets   = ticket_obj.hitung_total_paid()
    total_revenue   = ticket_obj.hitung_total_revenue()
    live_data_konser = ticket_obj.get_live_data_per_konser()

    db.close()
    return render_template('index.html',
        total_concerts=total_concerts,
        total_customers=total_customers,
        total_tickets=total_tickets,
        total_revenue=total_revenue,
        live_data_konser=live_data_konser
    )



#  Admin CRUD Konser

@app.route('/concerts')
@admin_required
def concerts():
    db = get_db()
    concert = Concert(db)
    data = concert.get_all()
    concert.close()
    return render_template('concerts.html', concerts=data)

@app.route('/concerts/add', methods=['GET', 'POST'])
@admin_required
def add_concert():
    if request.method == 'POST':
        db = get_db()
        concert = Concert(db)
        concert.tambah(
            request.form['title'], request.form['artist'],
            request.form['venue'], request.form['event_date'],
            request.form['price'], request.form['quota']
        )
        concert.close()
        flash('Konser berhasil ditambahkan!', 'success')
        return redirect(url_for('concerts'))
    return render_template('concert_form.html', concert=None)

@app.route('/concerts/edit/<int:id>', methods=['GET', 'POST'])
@admin_required
def edit_concert(id):
    db = get_db()
    concert = Concert(db)
    if request.method == 'POST':
        concert.update(
            id, request.form['title'], request.form['artist'],
            request.form['venue'], request.form['event_date'],
            request.form['price'], request.form['quota']
        )
        concert.close()
        flash('Konser berhasil diupdate!', 'success')
        return redirect(url_for('concerts'))
    data = concert.get_by_id(id)
    concert.close()
    return render_template('concert_form.html', concert=data)

@app.route('/concerts/delete/<int:id>')
@admin_required
def delete_concert(id):
    db = get_db()
    concert = Concert(db)
    concert.hapus(id)
    concert.close()
    flash('Konser berhasil dihapus!', 'danger')
    return redirect(url_for('concerts'))



#Admin CRUD Customer

@app.route('/customers')
@admin_required
def customers():
    db = get_db()
    customer = Customer(db)
    data = customer.get_all()
    customer.close()
    return render_template('customers.html', customers=data)

@app.route('/customers/add', methods=['GET', 'POST'])
@admin_required
def add_customer():
    if request.method == 'POST':
        db = get_db()
        customer = Customer(db)
        customer.tambah(
            request.form['name'], request.form['email'],
            request.form['phone'], request.form.get('password', '12345678')
        )
        customer.close()
        flash('Customer berhasil ditambahkan!', 'success')
        return redirect(url_for('customers'))
    return render_template('customer_form.html', customer=None)

@app.route('/customers/edit/<int:id>', methods=['GET', 'POST'])
@admin_required
def edit_customer(id):
    db = get_db()
    customer = Customer(db)
    if request.method == 'POST':
        customer.update(id, request.form['name'], request.form['email'], request.form['phone'])
        customer.close()
        flash('Customer berhasil diupdate!', 'success')
        return redirect(url_for('customers'))
    data = customer.get_by_id(id)
    customer.close()
    return render_template('customer_form.html', customer=data)

@app.route('/customers/delete/<int:id>')
@admin_required
def delete_customer(id):
    db = get_db()
    customer = Customer(db)
    customer.hapus(id)
    customer.close()
    flash('Customer berhasil dihapus!', 'danger')
    return redirect(url_for('customers'))


#Admin CRUD Tiket

@app.route('/tickets')
@admin_required
def tickets():
    db = get_db()
    ticket = Ticket(db)
    data = ticket.get_all()
    ticket.close()
    return render_template('tickets.html', tickets=data)

@app.route('/tickets/add', methods=['GET', 'POST'])
@admin_required
def add_ticket():
    db = get_db()
    if request.method == 'POST':
        concert_id  = request.form['concert_id']
        customer_id = request.form['customer_id']
        quantity    = int(request.form['quantity'])
        status      = request.form['status']

        concert_obj = Concert(db)
        concert = concert_obj.get_by_id(concert_id)
        total_price = concert['price'] * quantity

        ticket = Ticket(db)
        ticket.tambah(concert_id, customer_id, quantity, total_price, status)
        db.close()
        flash('Tiket berhasil ditambahkan!', 'success')
        return redirect(url_for('tickets'))

    concert_obj = Concert(db)
    concerts = concert_obj.get_all()
    customer_obj = Customer(db)
    customers_list = customer_obj.get_all()
    db.close()
    return render_template('ticket_form.html', ticket=None, concerts=concerts, customers=customers_list)

@app.route('/tickets/edit/<int:id>', methods=['GET', 'POST'])
@admin_required
def edit_ticket(id):
    db = get_db()
    if request.method == 'POST':
        concert_id  = request.form['concert_id']
        customer_id = request.form['customer_id']
        quantity    = int(request.form['quantity'])
        status      = request.form['status']

        concert_obj = Concert(db)
        concert = concert_obj.get_by_id(concert_id)
        total_price = concert['price'] * quantity

        ticket = Ticket(db)
        ticket.update(id, concert_id, customer_id, quantity, total_price, status)
        db.close()
        flash('Tiket berhasil diupdate!', 'success')
        return redirect(url_for('tickets'))

    ticket_obj = Ticket(db)
    ticket_data = ticket_obj.get_by_id(id)
    concert_obj = Concert(db)
    concerts = concert_obj.get_all()
    customer_obj = Customer(db)
    customers_list = customer_obj.get_all()
    db.close()
    return render_template('ticket_form.html', ticket=ticket_data, concerts=concerts, customers=customers_list)

@app.route('/tickets/delete/<int:id>')
@admin_required
def delete_ticket(id):
    db = get_db()
    ticket = Ticket(db)
    ticket.hapus(id)
    ticket.close()
    flash('Tiket berhasil dihapus!', 'danger')
    return redirect(url_for('tickets'))



#  ROUTES - Laporan
@app.route('/laporan')
@admin_required
def laporan():
    status_filter = request.args.get('status', 'semua')

    db = get_db()
    ticket_obj = Ticket(db)

    semua_tiket = ticket_obj.get_laporan(status_filter)
    rekap_konser = ticket_obj.get_rekap_per_konser()
    total_revenue = ticket_obj.hitung_total_revenue()
    total_tiket_paid = ticket_obj.hitung_total_paid()

    db.close()
    return render_template('laporan.html',
        tikets=semua_tiket,
        rekap_konser=rekap_konser,
        total_revenue=total_revenue,
        total_tiket_paid=total_tiket_paid,
        status_filter=status_filter
    )


@app.route('/laporan/download')
@admin_required
def laporan_download():
    status_filter = request.args.get('status', 'semua')

    db = get_db()
    ticket_obj = Ticket(db)
    data = ticket_obj.get_laporan(status_filter)
    db.close()

    # --- Susun PDF sederhana: judul + satu tabel ---
    buffer = io.BytesIO()
    doc = SimpleDocTemplate(
        buffer,
        pagesize=landscape(A4),
        leftMargin=25, rightMargin=25, topMargin=25, bottomMargin=25
    )

    styles = getSampleStyleSheet()
    cell_style = ParagraphStyle('cell', parent=styles['Normal'], fontSize=8, leading=10)

    elements = []

    judul = "Laporan Penjualan Tiket Konser"
    if status_filter != 'semua':
        judul += f" (Status: {status_filter.capitalize()})"
    elements.append(Paragraph(judul, styles['Title']))
    elements.append(Paragraph(
        f"Dicetak: {datetime.now().strftime('%d-%m-%Y %H:%M')} &nbsp;&nbsp;|&nbsp;&nbsp; Total Transaksi: {len(data)}",
        styles['Normal']
    ))
    elements.append(Spacer(1, 10))

    header = ["No", "Konser", "Artist", "Venue", "Customer", "Qty", "Total Harga", "Status", "Tanggal"]
    table_data = [header]

    total_qty = 0
    total_nominal = 0
    for i, t in enumerate(data, start=1):
        total_qty += t['quantity']
        total_nominal += t['total_price']
        table_data.append([
            str(i),
            Paragraph(t['concert_title'], cell_style),
            Paragraph(t['artist'], cell_style),
            Paragraph(t['venue'], cell_style),
            Paragraph(t['customer_name'], cell_style),
            str(t['quantity']),
            "Rp {:,.0f}".format(t['total_price']),
            t['status'].capitalize(),
            str(t['created_at']),
        ])

    if not data:
        table_data.append(["-", "Tidak ada data", "-", "-", "-", "-", "-", "-", "-"])

    col_widths = [25, 130, 95, 95, 105, 30, 80, 55, 100]
    table = Table(table_data, colWidths=col_widths, repeatRows=1)
    table.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#1e3a5f')),
        ('TEXTCOLOR', (0, 0), (-1, 0), colors.white),
        ('FONTSIZE', (0, 0), (-1, 0), 9),
        ('FONTSIZE', (0, 1), (-1, -1), 8),
        ('GRID', (0, 0), (-1, -1), 0.5, colors.HexColor('#cccccc')),
        ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
        ('ALIGN', (0, 0), (0, -1), 'CENTER'),
        ('ALIGN', (5, 0), (5, -1), 'CENTER'),
        ('ALIGN', (6, 0), (7, -1), 'CENTER'),
        ('ALIGN', (8, 0), (8, -1), 'CENTER'),
        ('ROWBACKGROUNDS', (0, 1), (-1, -1), [colors.white, colors.HexColor('#f5f7fa')]),
    ]))
    elements.append(table)
    elements.append(Spacer(1, 12))

    elements.append(Paragraph(f"Total Qty Tiket: {total_qty}", styles['Normal']))
    elements.append(Paragraph("Total Nominal: Rp {:,.0f}".format(total_nominal), styles['Normal']))

    doc.build(elements)
    buffer.seek(0)

    nama_file = f"laporan_tiket_{status_filter}_{datetime.now().strftime('%Y%m%d_%H%M')}.pdf"
    return send_file(buffer, as_attachment=True, download_name=nama_file, mimetype='application/pdf')


if __name__ == '__main__':
    app.run(debug=True)
